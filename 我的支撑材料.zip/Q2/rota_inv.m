%按先y轴再z轴旋转(rota_inv)
function pos_p = rota_inv(thetay,thetaz,pos)
Rz = [cos(thetaz) sin(thetaz) 0; -sin(thetaz) cos(thetaz) 0; 0 0 1];
Ry = [cos(thetay) 0 -sin(thetay); 0 1 0; sin(thetay) 0 cos(thetay)];
M = Rz*Ry;
pos_p = M*pos;
end