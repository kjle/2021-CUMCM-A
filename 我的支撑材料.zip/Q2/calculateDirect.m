%计算方向单位向量
function [x_dir,y_dir,z_dir] = calculateDirect(pos)
    x = pos(1);
    y = pos(2);
    z = pos(3);
    mo = sqrt(x^2 + y^2 + z^2);
    x_dir = x/mo;
    y_dir = y/mo;
    z_dir = z/mo;
end