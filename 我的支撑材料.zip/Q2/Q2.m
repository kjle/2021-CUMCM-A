%坐标旋转
clc
clear all
close all

load('mainPoint.mat');
load('move.mat');
load('node.mat');
mainPoint_ori = mainPoint.data;%备份原坐标，n*3
res1 = [];
res2 = [];%第二张表格的结果包括change_idx和res2
res3 = [];
alpha = deg2rad(36.795);
beta = deg2rad(78.169);
R = 300;
F = 0.466 * R;
%Q1中解得的理想抛物面参数
a = -300.0837;
c = 168196.217;
%x,y,z:原坐标
x = mainPoint.data(:,1);
y = mainPoint.data(:,2);
z = mainPoint.data(:,3);
%对原有坐标旋转，使得S位于Z轴上
thetaz = alpha;
thetay = pi/2-beta;
[m,n] = size(x);
for i=1:m
   pos = [x(i) y(i) z(i)]';
   pos_p = rota(thetay,thetaz,pos); 
   xx(i) = pos_p(1);
   yy(i) = pos_p(2);
   zz(i) = pos_p(3);
end
mainPoint_rot = [xx; yy; zz]';%旋转后的主索节点坐标
fig1 = figure('numbertitle','off','name','旋转后的主索节点坐标');
scatter3(xx,yy,zz,'*','MarkerEdgeColor','#5352ed');
hold on;
scatter3(x,y,z,'.','MarkerEdgeColor','#ff7f50');
legend('after','before');
%title('旋转后的主索节点坐标','FontSize',16);
xlabel('x-axis, m');
ylabel('y-axis, m');
zlabel('z-axis, m');
grid on;
axis equal ;
%%
%寻找在口径300内的主索节点（编号）
D = 300;%口径
mainPoint_rotIndex = zeros(m,1);%在口径内的主索节点编号
change_idx = [];%主索节点编号（有序，string）,1*n
for i=1:m
    x = mainPoint_rot(i,1);
    y = mainPoint_rot(i,2);
    if x^2 + y^2 <= (D/2)^2
        mainPoint_rotIndex(i) = 1;
        change_idx = [change_idx ;string(mainPoint.textdata(i))];
    end
end

%检查找到的主索节点是否正确
%xx,yy,zz: 提取旋转后的坐标且在口径300内
xx = [];
yy = [];
zz = [];
for i=1:m
    if mainPoint_rotIndex(i)
        xx = [xx; mainPoint_rot(i,1)];
        yy = [yy; mainPoint_rot(i,2)];
        zz = [zz; mainPoint_rot(i,3)];
    end
end
fig2 = figure('numbertitle','off','name','检查找到的主索节点是否正确');
scatter3(xx,yy,zz,'.','MarkerEdgeColor','#5352ed');
%%
%在相同的径向下，计算由Q1解得的理想抛物面的z坐标z_ideal
%计算径向方向向量
for i = 1:sum(mainPoint_rotIndex)
    [xx_dir(i),yy_dir(i),zz_dir(i)] = calculateDirect([xx(i) yy(i) zz(i)]);
end
%理想抛物面上的坐标
x_ideal = [];
y_ideal = [];
z_ideal = [];
k = [];%缩放调节量
for i=1:sum(mainPoint_rotIndex) 
    syms p
    eqns = [(zz(i)+p*zz_dir(i)) == ((xx(i)+p*xx_dir(i)).^2 + (yy(i)+p*yy_dir(i)).^2 - c)./(4*(-0.534*R-a))];
    S = solve(eqns,p);
    lambda = vpa(S(2,1));
    if lambda<-0.6
        lambda = -0.6;
    end
    if lambda >0.6
        lambda = 0.6;
    end
    tx = vpa(xx(i) + lambda*xx_dir(i));
    ty = vpa(yy(i) + lambda*yy_dir(i));
    tz = vpa(zz(i) + lambda*zz_dir(i));
    x_ideal = [x_ideal; tx];
    y_ideal = [y_ideal; ty];
    z_ideal = [z_ideal; tz];
    k = [k;lambda];
end
k = double(k);
k = -1*k;
%绘制
fig3 = figure('numbertitle','off','name','理想抛物面与实际的主索节点');
scatter3(x_ideal,y_ideal,z_ideal,50,'.');
hold on;
scatter3(xx,yy,zz);
%%
%求解调整后的主索节点坐标
tmpx = [];
tmpy = [];
tmpz = [];
for i = 1:m
    [x_dir(i),y_dir(i),z_dir(i)] = calculateDirect(mainPoint_ori(i,:));
end

cnt = 1;%调节的主索节点个数
mainPoint_change = mainPoint_ori;%调节后的主索节点坐标
for i=1:m
   if mainPoint_rotIndex(i) 
       %按径向修改节点坐标
       tx = mainPoint_ori(i,1) + (-k(cnt))*x_dir(i);
       ty = mainPoint_ori(i,2) + (-k(cnt))*y_dir(i);
       tz = mainPoint_ori(i,3) + (-k(cnt))*z_dir(i);
       cnt = cnt+1;
       tmpx = [tmpx;tx];
       tmpy = [tmpy;ty];
       tmpz = [tmpz;tz];
       mainPoint_change(i,:) = [tx ty tz];
   end
end
res2 = [tmpx tmpy tmpz];
%理想抛物面顶点坐标需要反相旋转回来
A = rota_inv(-thetay,-thetaz,[0 0 -300.0913]');
A = A';
res1 = A;
res3 = k;

%绘制修改过主索节点后的坐标
fig4 = figure('numbertitle','off','name','调节后主索节点坐标');
scatter3(mainPoint_ori(:,1),mainPoint_ori(:,2),mainPoint_ori(:,3),'.','MarkerEdgeColor','#5352ed');
hold on
scatter3(res2(:,1),res2(:,2),res2(:,3),50,k,'*');
%title('调节后主索节点坐标','FontSize',16);
xlabel('x-axis, m');
ylabel('y-axis, m');
zlabel('z-axis, m');
h = colorbar;
set(get(h,'label'),'string','move-distance,m');
colormap('cool')
grid on;
axis equal;
save('index.mat','change_idx');%导出修改的坐标序号集合
save('new.mat','mainPoint_change');%导出修改后主索节点坐标
