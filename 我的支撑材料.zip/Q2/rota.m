%按先z轴再y轴旋转
function pos_p = rota(thetay,thetaz,pos)
Rz = [cos(thetaz) sin(thetaz) 0; -sin(thetaz) cos(thetaz) 0; 0 0 1];
Ry = [cos(thetay) 0 -sin(thetay); 0 1 0; sin(thetay) 0 cos(thetay)];
M = Ry*Rz;
pos_p = M*pos;
end