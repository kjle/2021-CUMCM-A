%绘制初始数据图像
clc
clear all
close all

load('mainPoint'); %给出了所有主索节点的坐标和编号
x = mainPoint.data(:,1);
y = mainPoint.data(:,2);
z = mainPoint.data(:,3);
%主索节点坐标绘图
fig1 = figure('numbertitle','off','name','主索节点（初始）') 
scatter3(x,y,z,'.','MarkerEdgeColor','#5352ed');
grid on;
%title('主索节点坐标','FontSize',16);
xlabel('x-axis, m');
ylabel('y-axis, m');
zlabel('z-axis, m');
axis equal;