%搜索，在已知范围内加大精度
clc
clear all
clear all

R = 300;
delta = 0.1;
x = -R-0.6:delta:R+0.6;
cnt = 1;

for a=-300.083-0.001:0.0001:-300.083+0.001
    for c=168196.216-0.001:0.00001:168196.216+0.001
       f = (-0.534*R-a);
      % c = -4*a*f;
       z = (x.^2-c)./(4*f);
       n = length(z);
       ljb = [];
       for i=1:n
          if(z(i) < -169.019 && x(i)^2+z(i)^2>=(R-0.6)^2 &&  x(i)^2+z(i)^2<=(R+0.6)^2)
             ljb(i,:) = [x(i) z(i)]; 
          else
              ljb(i,:) = [0 0];
          end
       end
       dz = diff(ljb(:,2));
       S = delta*trapz((1+dz.^2).^0.5);
       res(cnt,1) = a;
       res(cnt,2) = c;
       res(cnt,3) = S;
       cnt = cnt+1;
    end
end
