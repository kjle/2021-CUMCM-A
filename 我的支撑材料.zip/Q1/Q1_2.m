%绘制抛物面与边界条件
clc
clear all
close all

load('mainPoint.mat');
load('move.mat');
load('node.mat');
R = 300;
F = 0.466 * R;

%初始的球面坐标
x_ini = mainPoint.data(:,1);
y_ini = mainPoint.data(:,2);
z_ini = mainPoint.data(:,3);
%坐标方向
[m,n] = size(x_ini);
for i = 1:m
   mo = sqrt(x_ini(i)^2 + y_ini(i)^2 + z_ini(i)^2);
   x_dir(i) = x_ini(i)/mo;
   y_dir(i) = y_ini(i)/mo;
   z_dir(i) = z_ini(i)/mo;
end
x_dir = x_dir';
y_dir = y_dir';
z_dir = z_dir';
%最小球面坐标
x_min = x_ini - 0.6*x_dir;
y_min = y_ini - 0.6*y_dir;
z_min = z_ini - 0.6*z_dir;
%最大球面坐标
x_max = x_ini + 0.6*x_dir;
y_max = y_ini + 0.6*y_dir;
z_max = z_ini + 0.6*z_dir;

[xq,yq] = meshgrid(-250:5:250,-250:5:250);

a = -300.0837;
c = 168196.217;
zh = (xq.^2+yq.^2 - c)./(4*(-0.534*R-a));
fig1 = figure('numbertitle','off','name','理想抛物线');
surf(xq,yq,zh,'FaceColor','#2ed573');

fig2 = figure('numbertitle','off','name','理想抛物线与边界条件');
zq_min = griddata(x_min,y_min,z_min,xq,yq);
mesh(xq,yq,zq_min,'EdgeColor','#ff4757','EdgeAlpha',0.5);
hold on;
zq_max = griddata(x_max,y_max,z_max,xq,yq);
mesh(xq,yq,zq_max,'EdgeColor','#5352ed','EdgeAlpha',0.5);
surf(xq,yq,zh,'FaceColor','#2ed573','FaceAlpha',1);
legend('min','max','ideal');
%title('理想抛物线与边界条件','FontSize',16);
xlabel('x-axis ,m');
ylabel('y-axis ,m');
zlabel('z-axis ,m');
zlim([-320 -100]);
xlim([-250 250]);
ylim([-250 250]);

fig3 = figure('numbertitle','off','name','理想抛物线与边界条件(俯视图)');
mesh(xq,yq,zq_min,'EdgeColor','#ff4757','EdgeAlpha',0.5);
hold on;
mesh(xq,yq,zq_max,'EdgeColor','#5352ed','EdgeAlpha',0.5);
surf(xq,yq,zh,'FaceColor','#2ed573','FaceAlpha',1);
xlim([-250 250]);
ylim([-250 250]);
xlabel('x-axis ,m');
ylabel('y-axis ,m');
view(0,90);
grid on;
axis equal;
