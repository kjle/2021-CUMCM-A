%已知三个点求其单位法向量
function [x,y,z] = pnorm(p1,p2,p3)
    a = p1-p2;
    b = p2-p3;
    c = cross(b,a);
    mo = sqrt(c(1)^2+c(2)^2+c(3)^2);
    x = c(1)/mo;
    y = c(2)/mo;
    z = c(3)/mo;
end