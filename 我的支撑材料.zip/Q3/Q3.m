close all
clear all
clc

load('index.mat');
load('mainPoint.mat');
load('node.mat');
load('new.mat');

alpha = deg2rad(36.795);
beta = deg2rad(78.169);
thetaz = alpha;
thetay = pi/2-beta;

%%
%旋转球面
mainPoint_change_rot = [];%修改后的主索节点做旋转
[m,n] = size(mainPoint_change);
for i=1:m
   pos = [mainPoint_change(i,1) mainPoint_change(i,2) mainPoint_change(i,3)]';
   pos_p = rota(thetay,thetaz,pos); 
   mainPoint_change_rot = [mainPoint_change_rot;pos_p'];
end
%%
%根据附件3，判断三角面中有多少个点在Q2解得的口径D内的点的集合内
[m,n] = size(node);
node_class = zeros(m,1);%对三角面分类，三个节点全在口径300内记为3
for i=1:m
    cnt = 0;
    for j = 1:3
        [h,l] = find(change_idx == node(i,1));
        if ~(isempty(h) && isempty(l))
            cnt = cnt + 1;
        end
    end
    node_class(i) = cnt;
end

%计算三角形面对应的中心
zhongxin = [];%三角面中心，n*3
node_norm = [];%三点的法向量
reflect = [];%反射方向向量
ru = [0 0 -1];%入射方向向量，由于经过旋转，使得方向竖直向下
for i=1:m
   if(node_class(i))
        [h1,l] = find(mainPoint.textdata == node(i,1)); 
        [h2,l] = find(mainPoint.textdata == node(i,2)); 
        [h3,l] = find(mainPoint.textdata == node(i,3)); 
        %取一个面的三个点
        p1 = mainPoint_change_rot(h1,:);
        p2 = mainPoint_change_rot(h2,:);
        p3 = mainPoint_change_rot(h3,:); 
        %计算面法向量
        [node_norm(i,1) node_norm(i,2) node_norm(i,3)]= pnorm(p1,p2,p3);
        zhongxin(i,:) = (p1+p2+p3)/3;
        reflect(i,:) = -2*dot(ru,node_norm(i,:))*node_norm(i,:) + ru;
   else
       zhongxin(i,:) = NaN;
       node_norm(i,:) = [NaN NaN NaN];
       reflect(i,:) = [NaN NaN NaN];
   end
end

%%
%求解能够使反射到达有效区域的三角面数量
R = 300;
cnt = 0;
hanghao = [];%反射直线能够在给定区域口径1的面的行号
huax = [];
huay =[];
huaz = [];%作反射直线的一个坐标
zx =[];
zy =[];
zz =[];%作反射直线的一个坐标
flag = node_class;%分区画图的标记
[huax,huay,huaz,zx,zy,zz,flag,hanghao,cnt] = calculate2ReflectPoint(zhongxin,reflect,node_class,0.5);

%%
%作反射直线当符合口径1
fig1 = figure('numbertitle',1,'name','抛物面反射直线');
axis equal;
hold on
N = 20;
er = 0.5;
r0 = linspace(0,er,N);
the = linspace(0,4*pi,N);
[r,theta] = meshgrid(r0,the);
z = -0.534*300*r.^0;
[x,y] = pol2cart(theta,r);
D = mesh(x,y,z,'FaceAlpha',0.1);
for i=1:3:size(zx)
    plot3([huax(i),zx(i) ],[huay(i),zy(i) ],[huaz(i),zz(i) ],'Color','#ff6b81','LineWidth',0.15);
end
xlabel('x-axis, m');
ylabel('y-axis, m');
zlabel('z-axis, m');
view(3);
grid on;
hold on;
rcv_cnt = cnt;%接收到的面数量
%%
%其他点作图
huax = [];
huay =[];
huaz = [];
zx =[];
zy =[];
zz =[];
[huax,huay,huaz,zx,zy,zz,flag,~,cnt] = calculate2ReflectPoint(zhongxin,reflect,node_class,10);

%%
for i=1:5:size(zx)
    plot3([huax(i),zx(i)],[huay(i),zy(i)],[huaz(i),zz(i)],'-','Color','#a4b0be','LineWidth',0.05);
end
scatter3(mainPoint_change_rot(:,1),mainPoint_change_rot(:,2),mainPoint_change_rot(:,3),'.','MarkerEdgeColor','#5352ed');
view(3);
grid on;

%%
fig2 = figure('numbertitle',2,'name','反射点情况');
fanshe = [];
for i=1:rcv_cnt
    idx = hanghao(i)
    p1 = node(idx,1)
    p2 = node(idx,2)
    p3 = node(idx,3)
    [h1,l] = find(mainPoint.textdata==p1);
    fanshe = [fanshe;mainPoint_change(h1,:)];
    [h1,l] = find(mainPoint.textdata==p2);
    fanshe = [fanshe;mainPoint_change(h1,:)];
    [h1,l] = find(mainPoint.textdata==p3);
    fanshe = [fanshe;mainPoint_change(h1,:)];
end
scatter3(fanshe(:,1),fanshe(:,2),fanshe(:,3),'o','MarkerEdgeColor','#ff7f50');
hold on;
scatter3(mainPoint_change(:,1),mainPoint_change(:,2),mainPoint_change(:,3),'.','MarkerEdgeColor','#5352ed');
axis equal;
xlabel('x-axis. m');
ylabel('y-axis, m');
zlabel('z-axis, m');

%%
%计算未经修改过球面
mainPoint_change_rot = [];
[m,n] = size(mainPoint_change);
for i=1:m
   pos = [mainPoint.data(i,1),mainPoint.data(i,2),mainPoint.data(i,3)]';
   pos_p = rota(thetay,thetaz,pos); 
   mainPoint_change_rot = [mainPoint_change_rot;pos_p'];
end

%%
%根据附件3，判断三角面中有多少个点在Q2解得的口径D内的点的集合内
[m,n] = size(node);
node_class = zeros(m,1);%对三角面分类，三个节点全在口径300内记为3
for i=1:m
    cnt = 0;
    for j = 1:3
        [h,l] = find(change_idx == node(i,1));
        if ~(isempty(h) && isempty(l))
            cnt = cnt + 1;
        end
    end
    node_class(i) = cnt;
end

%计算三角形面对应的中心
zhongxin = [];%三角面中心，n*3
node_norm = [];%三点的法向量
reflect = [];%反射方向向量
ru = [0 0 -1];%入射方向向量，由于经过旋转，使得方向竖直向下
for i=1:m
   if(node_class(i))
        [h1,l] = find(mainPoint.textdata == node(i,1)); 
        [h2,l] = find(mainPoint.textdata == node(i,2)); 
        [h3,l] = find(mainPoint.textdata == node(i,3)); 
        %取一个面的三个点
        p1 = mainPoint_change_rot(h1,:);
        p2 = mainPoint_change_rot(h2,:);
        p3 = mainPoint_change_rot(h3,:); 
        %计算面法向量
        [node_norm(i,1) node_norm(i,2) node_norm(i,3)]= pnorm(p1,p2,p3);
        zhongxin(i,:) = (p1+p2+p3)/3;
        reflect(i,:) = -2*dot(ru,node_norm(i,:))*node_norm(i,:) + ru;
   else
       zhongxin(i,:) = NaN;
       node_norm(i,:) = [NaN NaN NaN];
       reflect(i,:) = [NaN NaN NaN];
   end
end

%%
%求解能够使反射到达有效区域的三角面数量
R = 300;
cnt = 0;
hanghao = [];%反射直线能够在给定区域口径1的面的行号
huax = [];
huay =[];
huaz = [];%作反射直线的一个坐标
zx =[];
zy =[];
zz =[];%作反射直线的一个坐标
flag = node_class;%分区画图的标记
[~,~,~,~,~,~,~,hanghao,ori_cnt] = calculate2ReflectPoint(zhongxin,reflect,node_class,0.5);
%%
fig3 = figure('numbertitle',3,'name','球面反射点情况');
fanshe2 = [];
for i=1:ori_cnt
    idx = hanghao(i)
    p1 = node(idx,1)
    p2 = node(idx,2)
    p3 = node(idx,3)
    [h1,l] = find(mainPoint.textdata==p1);
    fanshe2 = [fanshe2;mainPoint_change(h1,:)];
     [h1,l] = find(mainPoint.textdata==p2);
    fanshe2 = [fanshe2;mainPoint_change(h1,:)];
     [h1,l] = find(mainPoint.textdata==p3);
    fanshe2 = [fanshe2;mainPoint_change(h1,:)];
end
scatter3(fanshe2(:,1),fanshe2(:,2),fanshe2(:,3),'o','MarkerEdgeColor','#ff7f50');
hold on;
scatter3(mainPoint.data(:,1),mainPoint.data(:,2),mainPoint.data(:,3),'.','MarkerEdgeColor','#5352ed');
axis equal;
xlabel('x-axis, m');
ylabel('y-axis, m');
zlabel('z-axis, m');
%%
%计算接受比
tot = sum(node_class)/3;
yita_change = rcv_cnt/tot;
yita_unchange = ori_cnt/tot;

