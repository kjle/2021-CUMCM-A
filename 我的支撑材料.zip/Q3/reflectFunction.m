function [reflectCnt, reflectIndex] = reflectFunction(tmp_idx,mainPoint,node,new)

    alpha = deg2rad(36.795);
    beta = deg2rad(78.169);
    thetaz = alpha;
    thetay = pi/2-beta;

    %旋转球面
    new_rot = [];
    [m,n] = size(new);
    for i=1:m
       pos = [new(i,1) new(i,2) new(i,3)]';
       %pos = [mainPoint.data(i,1),mainPoint.data(i,2),mainPoint.data(i,3)]';
       pos_p = rota(thetay,thetaz,pos); 
       new_rot = [new_rot;pos_p'];
    end
    %scatter3(new_rot(:,1),new_rot(:,2),new_rot(:,3));
    %%
    %根据附件3，判断三角面中有多少个点在Q2解得的口径D内的点的集合内
    [m,n] = size(node);
    node_class = zeros(m,1);
    for i=1:m
        cnt = 0;
        for j = 1:3
            [h,l] = find(tmp_idx == node(i,1));
            if ~(isempty(h) && isempty(l))
                cnt = cnt + 1;
            end
        end
        node_class(i) = cnt;
    end

    %计算三角形面对应的中心
    zhongxin = [];
    node_norm = [];%三点的法向量
    reflect = [];
    ru = [0 0 -1];
    for i=1:m
       if(node_class(i))
            [h1,l] = find(mainPoint.textdata == node(i,1)); 
            [h2,l] = find(mainPoint.textdata == node(i,2)); 
            [h3,l] = find(mainPoint.textdata == node(i,3)); 
            p1 = new_rot(h1,:);
            p2 = new_rot(h2,:);
            p3 = new_rot(h3,:); 
            [node_norm(i,1), node_norm(i,2), node_norm(i,3)]= pnorm(p1,p2,p3);
            zhongxin(i,:) = (p1+p2+p3)/3;
            reflect(i,:) = -2*dot(ru,node_norm(i,:))*node_norm(i,:) + ru;
       else
           zhongxin(i,:) = NaN;
           node_norm(i,:) = [NaN NaN NaN];
           reflect(i,:) = [NaN NaN NaN];
       end
    end
    %scatter3(zhongxin(:,1),zhongxin(:,2),zhongxin(:,3));

    %%
    %求解能够使反射到达有效区域的三角面数量
    R = 300;
    cnt = 0;
    knot = [];
    for i=1:m
        if(node_class(i))
            px = zhongxin(i,1);
            py = zhongxin(i,2);
            pz = zhongxin(i,3);
            syms k
            eqns = [ (zhongxin(i,1)+k*reflect(i,1))^2 + (zhongxin(i,2)+k*reflect(i,2))^2 <= 0.25,(zhongxin(i,3)+k*reflect(i,3))==-0.534*300];
            S = solve(eqns, [k]);
            if S
                cnt = cnt + 1
                knot = [knot;i];
            end
        end
    end
    reflectCnt = cnt;
    reflectIndex = knot;
end