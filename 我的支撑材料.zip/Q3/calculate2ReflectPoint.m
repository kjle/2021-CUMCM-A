%计算反射直线上的两个点
%flag 画图区分标志
%hanghao 反射直线能够在给定区域口径1的面的行号
%cnt 计算的面数量
%区域半径
function [Ax,Ay,Az,Bx,By,Bz,flag,hanghao,cnt] = calculate2ReflectPoint(zhongxin,reflect,node_class,r)
    cnt = 0;
    hanghao = [];
    Ax = [];
    Ay =[];
    Az = [];%作反射直线的一个坐标
    Bx =[];
    By =[];
    Bz =[];%作反射直线的一个坐标
    r=r+0.1;
    for i=1:4300
        if(node_class(i))
            px = zhongxin(i,1);
            py = zhongxin(i,2);
            pz = zhongxin(i,3);
            syms k
            eqns = [ (zhongxin(i,1)+k*reflect(i,1))^2 + (zhongxin(i,2)+k*reflect(i,2))^2 <= r^2,(zhongxin(i,3)+k*reflect(i,3))==-0.534*300];
            S = solve(eqns, [k]);
            if S
                flag(i) = 0;
                cnt = cnt + 1
                hanghao = [hanghao;i];
                k0=double(S);
                Bx = [Bx;zhongxin(i,1)];
                By = [By;zhongxin(i,2)];
                Bz = [Bz;zhongxin(i,3)];
                Ax = [Ax;zhongxin(i,1) + k0*reflect(i,1)];
                Ay = [Ay;zhongxin(i,2) + k0*reflect(i,2)];
                Az = [Az;zhongxin(i,3) + k0*reflect(i,3)];
            end
        end
    end

end